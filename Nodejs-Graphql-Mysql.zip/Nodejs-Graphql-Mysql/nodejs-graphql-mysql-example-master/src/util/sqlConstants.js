module.exports = {
    ASC: "asc",
    DESC: "desc"
}