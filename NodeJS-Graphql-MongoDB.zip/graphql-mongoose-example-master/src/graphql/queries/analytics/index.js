import analytics from "./analytics";

export default {
  analytics
}
