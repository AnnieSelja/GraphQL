import analitycsQuery from "./analytics";

export default analitycsQuery;
