import analyticsMutation from './analytics';

export default analyticsMutation;
