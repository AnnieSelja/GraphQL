import addData from "./add";
import UpdateData from "./update";
import remove from "./remove";

export default {
    addData,
    UpdateData,
    remove
}
